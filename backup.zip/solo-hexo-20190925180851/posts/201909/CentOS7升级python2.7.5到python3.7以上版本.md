title: CentOS7升级python2.7.5到python3.7以上版本
date: '2019-09-14 18:00:59'
updated: '2019-09-14 18:10:47'
tags: [Python, CentOS]
permalink: /articles/2019/09/14/1568455259699.html
---
![](https://img.hacpai.com/bing/20171111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

CentOS7中自带的python版本是python-2.7.5，由于新开的虚拟机需要使用python3，于是便升级一下版本。

## 安装Python3.7.3
官网下载地址：[](https://www.python.org/downloads/source/)[https://www.python.org/downlo...](https://www.python.org/downloads/source/)

![TIM截图20190914175817.png](https://img.hacpai.com/file/2019/09/TIM截图20190914175817-9faa4250.png)

```
# 下载
wget https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz
# 解压
tar -zxf Python-3.7.3.tgz
# 安装依赖包
yum install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gcc  libffi-devel
# 进入python目录
cd Python-3.7.3
# 编译
./configure --prefix=/usr/local/python3.7
#安装
make && make install
```
关于Python3.7以上的版本，需要多安装一个依赖包:
```
yum install -y libffi-devel
```
否则会出现`ModuleNotFoundError: No module named '_ctypes'`的报错。

在make install后执行`echo $?`，为0表示没有出错。如果没有报错，在/usr/local会生成python3.7目录。
**然后将系统默认的python2备份**

```
mv /usr/bin/python /usr/bin/python.bak
```

**创建新的软连接**

```
ln -s /usr/local/python/bin/python3.7 /usr/bin/python
```

**查看版本**

```
[root@moli-linux03 src]# python -V
Python 3.7.3     

```

升级完成了。

## 更改yum配置

因为yum需要使用python2，将/usr/bin/python改为python3后，yum就不能正常运行了，因此需要更改一下yum的配置。

```
vim /usr/bin/yum
vim /usr/libexec/urlgrabber-ext-down
```

编辑这两个文件，将文件头的`#!/usr/bin/python`改为`#!/usr/bin/python2`即可。

## 配置pip

Python3装完后，默认已经安装了pip，此时只要配置下软链接即可使用pip工具：

```
ln -s /usr/local/python3/bin/pip3  /usr/bin/pip
```
