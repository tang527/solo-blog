title: CentOS 7 防火墙相关问题
date: '2019-09-17 22:30:15'
updated: '2019-09-19 17:39:36'
tags: [CentOS, firewall]
permalink: /articles/2019/09/17/1568730615726.html
---
## 工具/原料

 

* 阿里云服务器centos
    

## 方法/步骤

 

1.  
    
    执行firewall-cmd --permanent --zone=public --add-port=3306/tcp，提示FirewallD is not running，如下图所示。
    
![7dd98d1001e939013391d96372ec54e737d196df.png](https://img.hacpai.com/file/2019/09/7dd98d1001e939013391d96372ec54e737d196df-b6c68b4f.png)

    
2.  
    
    通过systemctl status firewalld查看firewalld状态，发现当前是dead状态，即防火墙未开启。
    
![55e736d12f2eb93882fe2eafdc628535e4dd6fdf.png](https://img.hacpai.com/file/2019/09/55e736d12f2eb93882fe2eafdc628535e4dd6fdf-f6417a26.png)

    
3.  
    
    通过systemctl start firewalld开启防火墙，没有任何提示即开启成功。
    
![e61190ef76c6a7efec9afc7bf4faaf51f3de662a.png](https://img.hacpai.com/file/2019/09/e61190ef76c6a7efec9afc7bf4faaf51f3de662a-3adb5554.png)

如果开启失败，提示 **# Failed to start firewalld.service: Unit is masked**
输入命令 `systemctl unmask firewalld`
即可解除锁定
如果下次需要锁定该服务，则用
`systemctl mask firewalld`
![20170804172515873.png](https://img.hacpai.com/file/2019/09/20170804172515873-98b770f2.png)

    
4.  
    
    再次通过systemctl status firewalld查看firewalld状态，显示running即已开启了。
    
![e61190ef76c6a7efec9afc7bf4faaf51f3de662a.png](https://img.hacpai.com/file/2019/09/e61190ef76c6a7efec9afc7bf4faaf51f3de662a-82e001a5.png)

    
5. 
    
    如果要关闭防火墙设置，可能通过systemctl stop firewalld这条指令来关闭该功能。
    
![503d269759ee3d6d9f44d3964a166d224e4adee9.png](https://img.hacpai.com/file/2019/09/503d269759ee3d6d9f44d3964a166d224e4adee9-5e68adc6.png)

    
6. 
    
    再次执行执行firewall-cmd --permanent --zone=public --add-port=3306/tcp，提示success，表示设置成功，这样就可以继续后面的设置了。
    
![42166d224f4a20a4969c689a99529822730ed0e9.png](https://img.hacpai.com/file/2019/09/42166d224f4a20a4969c689a99529822730ed0e9-40cbb91f.png)

    
 7.
`开启端口后，执行 firewall-cmd --reload 重启防火墙服务，即可开放端口`
![TIM截图20190917223629.png](https://img.hacpai.com/file/2019/09/TIM截图20190917223629-3d648ec3.png)


8.
**一些常用的防火墙命令**

* 查看已经开放的端口
`firewall-cmd --list-ports` 
![image.png](https://img.hacpai.com/file/2019/09/image-28d89031.png)

* 开启端口
`firewall-cmd --zone=public --add-port=80/tcp --permanent`

-zone **#作用域**
–add-port=80/tcp **#添加端口，格式为：端口/通讯协议**
–permanent  **#永久生效，没有此参数重启后失效**

* 重启防火墙
`firewall-cmd --reload` #重启firewall
`systemctl stop firewalld.service` #停止firewall
`systemctl disable firewalld.service` #禁止firewall开机启动

`firewall-cmd --state` #查看默认防火墙状态（关闭后显示notrunning，开启后显示running）
