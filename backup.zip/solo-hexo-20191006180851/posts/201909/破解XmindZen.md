title: 破解Xmind Zen
date: '2019-09-16 19:21:27'
updated: '2019-09-16 19:21:27'
tags: [软件破解, Xmind]
permalink: /articles/2019/09/16/1568632887155.html
---
文章目录
1 这个软件的一些操作和效果图hiahiahia
2 非常不正经的无限延长使用版本
第零步：下载安装
第一步：必须先进入软件，新建一个思维导图，产生用户状态文件就行。
第二步：打开路径：C:\Users\你的电脑名称\AppData\Roaming\XMind ZEN\Electron v3\vana\state
1 这个软件的一些操作和效果图hiahiahia
XMind ZEN 是一款怎样的产品？ - XMind的回答 - 知乎
https://www.zhihu.com/question/65056372/answer/312725672

2 非常不正经的无限延长使用版本
第零步：下载安装
https://www.xmind.cn/download/zen
直接下一步安装，安装后打开软件显示试用模式（7天）

第一步：必须先进入软件，新建一个思维导图，产生用户状态文件就行。
然后关闭软件Xmind ZEN

第二步：打开路径：C:\Users\你的电脑名称\AppData\Roaming\XMind ZEN\Electron v3\vana\state
找不到就设置显示隐藏文件，这个路径是在隐藏文件夹下面的
不然文件修改了也保存不了
找到activation.json文件，记事本打开

把数值改成如下图内容：
其实也可以改成别的这个可以随便试试

保存后，再次打开Xmind：

将近能用50年。。。。。。
如果那个时候我还在用斯文盗图我应该还有很多头发，并且不会得老年痴呆？

————————————————

