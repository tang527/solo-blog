title: 安装Docker最新版本
date: '2019-09-23 10:36:58'
updated: '2019-09-23 10:36:58'
tags: [Docker, Linux]
permalink: /articles/2019/09/23/1569206218337.html
---
之前安装的Docker 版本低于1.9，所以无法使用docker network命令来创建网络，需卸载重新安装最新版本的docker,其中docker-ce是Docker社区版本,目前最新的是18.03.1-ce。yum安装采用的是阿里云镜像加速。

##  yum卸载、安装
卸载老版本的 docker 及其相关依赖

`sudo yum remove docker docker-common container-selinux docker-selinux docker-engine`

#### 安装 yum-utils，它提供了 yum-config-manager，可用来管理yum源

`sudo yum install -y yum-utils`

#### 添加yum源

`sudo yum-config-manager --add-repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo`

#### 更新yum索引

`sudo yum makecache fast`

#### 安装 docker-ce

```sudo yum install docker-ce```

#### 启动 docker

`sudo systemctl start docker`

#### 验证是否安装成功

`sudo docker info`

#### 安装指定版本的Docker-ce

```
yum list docker-ce --showduplicates|sort -r  
yum install 18.03.1.ce -y
```

#### 卸载Docker-ce

### 卸载
```
yum remove docker-ce  
rm -rf /var/lib/docker
```
