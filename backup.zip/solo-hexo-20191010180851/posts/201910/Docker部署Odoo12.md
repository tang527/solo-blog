title: Docker部署Odoo12
date: '2019-10-09 09:29:48'
updated: '2019-10-09 09:32:55'
tags: [Odoo, Docker]
permalink: /articles/2019/10/09/1570584588820.html
---
### 在docker上部署odoo

  

1、拉取一个**大象数据库postgres的镜像**并作为容器

```
sudo docker run -p 5432:5432 -d -e POSTGRES_USER=odoo -e POSTGRES_PASSWORD=odoo -e POSTGRES_DB=postgres --name db postgres:10
```
2、拉取一个**odoo12并映射端口**作为容器

```
sudo docker run -p 8069:8069 --name odoo --link db:db -t odoo
```

3、**挂载数据卷**

```
sudo docker run -p 8069:8069 --name odoo -v /home/zhuhau/PycharmProjects/addons:/usr/lib/python3/dist-packages/odoo/addons --link db:db -t odoo
```

4、**设置docker启动后自启动该容器**


```
docker update --restart=always xxx
```
其中  `xxx`  是容器名
如：
```
docker update --restart=always db
```

