title: Ubuntu中Docker去掉sudo权限
date: '2019-09-22 22:57:27'
updated: '2019-09-22 22:57:27'
tags: [Docker, Ubuntu]
permalink: /articles/2019/09/22/1569164247459.html
---
**查看用户组及成员**

`sudo cat /etc/group | grep docker`

可以**添加docker组**

`sudo groupadd docker`

**添加用户到docker组 **
下面的 ${USER} 就是你用户的名字，如 **tang**

`sudo gpasswd -a ${USER} docker`

**增加读写权限**

 `sudo chmod a+rw /var/run/docker.sock`
**重启docker**

`sudo systemctl restart docker`

