title: odoo字段参数
date: '2019-10-07 11:59:02'
updated: '2019-10-07 11:59:02'
tags: [Odoo, Python]
permalink: /articles/2019/10/07/1570420742506.html
---
# 1.基础文件及目录结构

在认识odoo ORM框架前，先介绍一下odoo中模块目录结构。  
   
 
![1553579345633024a732fd4a14ef690933929d2f8a94a.png](https://img.hacpai.com/file/2019/10/1553579345633024a732fd4a14ef690933929d2f8a94a-14302ec1.png)

`data`：存放模块预制数据  
`i18n`：存放国际化文件  
`models`：存放模型等py代码  
`security`：存放权限文件  
`views`：存放视图文件  
`__manifest__.py`：该文件用于声明该模块，并指定一些模块元数据。（odoo8时该文件为`__openerp__.py`。）

```
# -*- coding: utf-8 -*- 
{ 
	# name:模块名称  
	'name': " test", 
	# description:模块描述  
	'description': """ 
		自定义模块 
	""", 
	# author:模块作者（XXX公司或张三）  
	'author': "Hu", 
	# website:作者或公司网址  
	'website': "http://weibo.com/hcw1202", 
	# category:模块分类  
	'category': "test", 
	# version:模块版本  
	'version': "版本", 
	# depends:所依赖其他模块  
	'depends': ["base","stock","sale"], 
	# 模块安装时加载  
	'data': [ 
		'security/权限文件.csv', 
		'data/预制数据.xml', 
		'views/视图文件.xml',
	 ], 
	# 创建数据库时勾选Load demonstration data后安装该模块加载演示数据  
	'demo': [ 
		'data/演示数据.xml', 
	], 
}
```

# 2.Model属性

在/models下添加`test.py`文件

```
# -*- coding: utf-8 -*-
from odoo import models, api, fields, _
class Test(models.Model):
    # 模型唯一标识（对应数据表为product_manage_product）
    _name = 'product_manage.product'
    # 数据显示名称，如设置则返回其指定的字段值
    _rec_name = 'test_field'
    # 字段
    test_field = fields.Char(string="字段名称")
```

### model属性详解：  
`_name`：**模型唯一标识**，类非继承父类时必须指定。  
`_rec_name`：**数据显示名称**，如设置则返回其指定的字段值，不设置默认显示字段为name的字段值，如无name字段则显示"模块名,id"；详见`BaseModel.name_get`方法。  
`_log_access`：**是否自动增加日志字段**（`create_uid`, `create_date`,`write_uid`, `write_date`）。默认为True。  
`_auto`：**是否创建数据库对象**。默认为True，详见BaseModel._auto_init方法。  
`_table`：**数据库对象名称**。缺省时数据库对象名称与_name指定值相同（`.`替换为下划线）。  
`_sequence`：**数据库id字段的序列**。默认自动创建序列。  
`_order`：**数据显示排序**。所指定值为模型字段，按指定字段和方式排序结果集。

> 例：_order = "create_date desc"：根据创建时间降序排列。可指定多个字段。  
> 不指定desc默认升序排列；不指定_order默认id升序排列。

`_constraints`：**自定义约束条件**。模型创建/编辑数据时触发，约束未通过弹出错误提示，拒绝创建/编辑。

> 格式：`_constraints = [(method, 'error message', [field1, ...]), ...]`  
> `method`：检查方法。返回True|False  
> `error message`：不符合检查条件时（method返回False）弹出的错误信息  
> `[field1, ...]`：字段名列表，这些字段的值会出现在error message中。

`_sql_constraints`：**数据库约束**。

> 例：`_sql_constraints = [ ('number_uniq', 'unique(number, code)', 'error message') ]`  
> 会在数据库添加约束：  
> `CONSTRAINT number_uniq UNIQUE(number, code)`

`_inherit`：**单一继承**。值为所继承父类_name标识。如子类不定义_name属性，则在父类中增加该子类下的字段或方法，不创建新对象；如子类定义_name属性，则创建新对象，新对象拥有父类所有的字段或方法，父类不受影响。

> 格式：`_inherit = '父类 _name'`

`_inherits`：**多重继承**。子类通过关联字段与父类关联，子类不拥有父类的字段或方法，但是可以直接操作父类的字段或方法。

> 格式：`_inherits = {'父类 _name': '关联字段'}`

# 3.字段属性

### 基础类型

`Char`：**字符型**，使用size参数定义字符串长度。  
`Text`：**文本型**，无长度限制。  
`Boolean`：**布尔型**（True，False）  
`Interger`：**整型**  
`Float`：**浮点型**，使用digits参数定义整数部分和小数部分位数。如`digits=(10,6)`  
`Datetime`：**日期时间型**  
`Date`：**日期型 ** 
`Binary`：**二进制型**  
`selection`：**下拉框字段**。

> 举例如下
```
state = fields.Selection(
	[
		('draft', 'Draft'),
		('confirm', 'Confirmed'),
		('cancel', 'Cancelled')
	], 
	string='Status'
)
```

`Html`：可设置字体格式、样式，可添加图片、链接等内容。效果如下：  

截于odoo自带项目管理模块  

![1553579345641c454dd6033b2461182f48d84b29d020c.png](https://img.hacpai.com/file/2019/10/1553579345641c454dd6033b2461182f48d84b29d020c-dd683cd2.png)


#### 关系类型

`One2many`：**一对多关系**。

> 定义：`otm = fields.One2many("关联对象 _name", "关联字段",string="字段显示名",...`)  
> 例：`analytic_line_ids = fields.One2many('account.analytic.line', 'move_id', string='Analytic lines')"`

`Many2one` : **多对一关系**

> 定义：`mto = fields.Many2one("关联对象 _name", string="字段显示名",...`)  
> 可选参数：ondelete，可选值为‘cascade’和‘null’，缺省为null。表示one端删除时many端是否级联删除。

`Many2many` : **多对多关系**

> 定义：`mtm = fields.Many2many("关联对象 _name", "关联表/中间表","关联字段1","关联字段2",string="字段显示名"`,...)  
> 其中，关联字段、关联表/中间表可不填，中间表缺省为：表1_表2_rel  
> 例：`partner_id= fields.Many2many("res.partner", string="字段显示名",...)"`

### 复杂类型

#### 参数

`readonly`：**是否只读**，缺省值False。  
`required`：**是否必填**，缺省值Falsse。  
`string`：**字段显示名**，任意字符串。  
`default`：**字段默认值**  
`domain`：**域条件**，缺省值[]。在关系型字段中，domain用于过滤关联表中数据。  
`help`：**字段描述**，鼠标滑过时提示。  
`store`：**是否存储于数据库**。结合compute和related使用。

> 例：
```
sale_order = fields.One2many(
	"sale.order", 
	"contract_id",
	string="销售订单", 
	domain=[('state','=','sale')]
)
```

`compute`：**字段值由函数计算**，该字段**可不储存于数据库**。

> 例：
```
amount = fields.Float(
	string="金额总计", 
	compute=‘_compute_amount’,
	store=True
)
```
> `_compute_amount`为计算函数。

`related`：**字段值引用关联表中某字段**。

> 以下代码表示：`company_id`引用`hr.payroll.advice`中`company_id`

```
advice_id = fields.Many2one('hr.payroll.advice', string='Bank Advice')
company_id = fields.Many2one('res.company', related='advice_id.company_id',
string='Company', store=True)
```

[原文链接](https://www.cnblogs.com/Kingfan1993/p/10784020.html)
