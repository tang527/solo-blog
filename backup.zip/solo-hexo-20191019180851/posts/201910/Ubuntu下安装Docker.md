title: Ubuntu下安装Docker
date: '2019-10-09 09:21:46'
updated: '2019-10-09 09:24:31'
tags: [Ubuntu, Docker, Linux]
permalink: /articles/2019/10/09/1570584106041.html
---
## Ubuntu版本16.04
### 首先更换**apt**的源

**第一步：备份原来的源文件**

`cd /etc/apt/ `

然后会显示下面的源文件sources.list

输入命令

`sudo cp sources.list sources.list.bak `

就是将**sources.list**备份到**sources.list.bak**

**第二步：替换源**

阿里云源的文件

```
deb http://mirrors.aliyun.com/ubuntu/ xenial main restricted universe multiverse 
deb http://mirrors.aliyun.com/ubuntu/ xenial-security main restricted universe multiverse 
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates main restricted universe multiverse 
deb http://mirrors.aliyun.com/ubuntu/ xenial-backports main restricted universe multiverse 
##测试版源 
deb http://mirrors.aliyun.com/ubuntu/ xenial-proposed main restricted universe multiverse 
# 源码 
deb-src http://mirrors.aliyun.com/ubuntu/ xenial main restricted universe multiverse 
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security main restricted universe multiverse 
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates main restricted universe multiverse 
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-backports main restricted universe multiverse 
##测试版源 
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-proposed main restricted universe multiverse 
# Canonical 合作伙伴和附加 
deb http://archive.canonical.com/ubuntu/ xenial partner 
deb http://extras.ubuntu.com/ubuntu/ xenial main 
```

替换并保存

`sudo gedit sources.list`打开文件，替换成阿里云文件即可

**第三步：更新源和软件**

```
sudo apt-get update 更新源    
sudo apt-get upgrade 更新软件
```

## 开始安装
* 由于apt官方库里的docker版本可能比较旧，所以先卸载可能存在的旧版本：

```
sudo apt-get remove docker docker-engine docker-ce docker.io
```


* 更新apt包索引：

```
sudo apt-get update
```



* 安装以下包以使apt可以通过HTTPS使用存储库（repository）：

```
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common
```


* 添加**Docker官方的GPG密钥**：

```
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
```


* 使用下面的命令来设置stable存储库：

```
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
```


* 再更新一下apt包索引：

```bash
sudo apt-get update
```


* 安装最新版本的Docker CE：

```bash
sudo apt-get install -y docker-ce
```


* 在生产系统上，可能会需要应该安装一个特定版本的Docker CE，而不是总是使用最新版本：

列出可用的版本：

```bash
apt-cache madison docker-ce
```
![2018030114340657.png](https://img.hacpai.com/file/2019/10/2018030114340657-b677374c.png)

选择要安装的特定版本，第二列是**版本字符串**，第三列是**存储库名称**，它指示**包来自哪个存储库**，以及扩展它的稳定性级别。要安装一个特定的版本，将**版本字符串附加到包名**中，并通过等号(=)分隔它们：

```
sudo apt-get install docker-ce=<VERSION>
```


## 验证docker

* 查看docker服务是否启动：

```
systemctl status docker
```



* 若未启动，则启动docker服务：

```
sudo systemctl start docker
```



* 经典的hello world：

```
sudo docker run hello-world
```

![2018030114340657.png](https://img.hacpai.com/file/2019/10/2018030114340657-b9fad47c.png)

有以上输出则证明docker已安装成功

