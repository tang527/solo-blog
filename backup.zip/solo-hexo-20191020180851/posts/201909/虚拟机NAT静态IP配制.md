title: 虚拟机 NAT静态IP配制
date: '2019-09-19 16:42:33'
updated: '2019-09-19 16:42:33'
tags: [CentOS, 网络配置]
permalink: /articles/2019/09/19/1568882553818.html
---
### 设置虚拟网络编辑器

只保留NAT模式的主机连接

关闭**DHCP**服务

  ![null](https://note.youdao.com/yws/public/resource/8125674d20f17c5cd10cabfe64a467b4/xmlnote/057DD2CBE9494BA7A6424BA50FD1505B/79)

  
### 查看虚拟网段

虚拟机网段为192.168.11.*，故可以给各个结点分配**192.168.11.2-255**的IP

![](https://note.youdao.com/yws/public/resource/8125674d20f17c5cd10cabfe64a467b4/xmlnote/93C665B5B2D342378DCEEA57704A93EB/48)

  

### 修改网络配制文件

`[root@LonelyZhe ~]# vim /etc/sysconfig/network-scripts/ifcfg-ens33`

  
```
TYPE="Ethernet"  
  
PROXY_METHOD="none"  
  
BROWSER_ONLY="no"  
  
BOOTPROTO="static"  
  
DEFROUTE="yes"  
  
IPV4_FAILURE_FATAL="no"  
  
IPV6INIT="yes"  
  
IPV6_AUTOCONF="yes"  
  
IPV6_DEFROUTE="yes"  
  
IPV6_FAILURE_FATAL="no"  
  
IPV6_ADDR_GEN_MODE="stable-privacy"  
  
NAME="ens33"  
  
HWADDR=00:0C:29:9A:A5:C2  
  
UUID="808be439-5a41-4cb1-8db2-769724b3e520"  
  
DEVICE="ens33"  
  
ONBOOT="yes"  
  
IPADDR=192.168.11.3 # 这些都是根据上图NAT设置中配制的  
  
NETMASK=255.255.255.0  
  
GATEWAY=192.168.11.2  
  
DNS1=8.8.8.8  
  
DNS2=8.8.4.4
```
  

### 重启网络服务

`[root@LonelyZhe ~]# systemctl restart network`
