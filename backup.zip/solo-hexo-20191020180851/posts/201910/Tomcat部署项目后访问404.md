title: Tomcat部署项目后访问404
date: '2019-10-14 21:52:03'
updated: '2019-10-14 21:52:03'
tags: [Tomcat, '404']
permalink: /articles/2019/10/14/1571061123131.html
---
### Tomcat 启动正常

![TIM截图20191014211933.png](https://img.hacpai.com/file/2019/10/TIM截图20191014211933-be9a4d74.png)

但是，访问自己的项目后，404

![5b5064060001af1e08090290.jpg](https://img.hacpai.com/file/2019/10/5b5064060001af1e08090290-dd3488a7.jpg)

首先检查 **Project Structure**,首先是 **project**：


![project.png](https://img.hacpai.com/file/2019/10/project-9229d244.png)


Modules-Sources如下图：

![sources.png](https://img.hacpai.com/file/2019/10/sources-31b3c205.png)

Modules-Dependencies如下图:

![dependencies.png](https://img.hacpai.com/file/2019/10/dependencies-d13623d5.png)

Facets如下，路径一定不要配错，不然会 404 如下图：

![Facets.png](https://img.hacpai.com/file/2019/10/Facets-ba8212f5.png)


最后就是 **Artifacts**——注意！，这个经常出错:

![Artifacts.png](https://img.hacpai.com/file/2019/10/Artifacts-fdb7c36f.png)

注意：**是可以选的，如果不能，可能问题就在这里**

![SelectModules.png](https://img.hacpai.com/file/2019/10/SelectModules-3ae92d7d.png)

最后看一下 **Tomcat 配置**

![tomcat配置.jpg](https://img.hacpai.com/file/2019/10/tomcat配置-0cf5b87c.jpg)

![Deployment.jpg](https://img.hacpai.com/file/2019/10/Deployment-e3a88b53.jpg)






