title: Docker部署Odoo12
date: '2019-10-09 09:29:48'
updated: '2019-10-10 22:20:35'
tags: [Odoo, Docker]
permalink: /articles/2019/10/09/1570584588820.html
---
### 在docker上部署odoo

  

#### 1、拉取一个**大象数据库postgres的镜像**并作为容器

```
sudo docker run -p 5432:5432 -d -e POSTGRES_USER=odoo -e POSTGRES_PASSWORD=odoo -e POSTGRES_DB=postgres --name db postgres:10
```
#### 2、拉取一个**odoo12并映射端口**作为容器

```
sudo docker run -p 8069:8069 --name odoo --link db:db -t odoo
```

#### 3、进入**odoo容器**并复制addons文件

```
sudo docker cp odoo:/usr/lib/python3/dist-packages/odoo/addons /home/odoo/odoo
```
> **将要使用的 odoo容器下的`addons`复制到`宿主机`**
> 做好**挂载前**的准备工作



#### 4、**挂载数据卷**

```
sudo docker run -p 8069:8069 --name odoo -v /home/odoo/odoo/addons:/usr/lib/python3/dist-packages/odoo/addons --link db:db -t odoo
```

#### 5、**设置docker启动后自启动该容器**


```
sudo docker update --restart=always xxx
```
其中  `xxx`  是容器名
如：
```
sudo docker update --restart=always db
```

### 在windows上修改并同步到虚拟机

#### 未完待续...

