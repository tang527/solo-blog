title: CentOS防火墙设置端口转发
date: '2019-09-19 17:33:57'
updated: '2019-10-09 09:40:25'
tags: [CentOS, 端口转发, firewall, 端口]
permalink: /articles/2019/09/19/1568885637667.html
---
### 伪装IP

防火墙可以实现伪装IP的功能，下面的**端口转发**就会用到此功能

```
firewall-cmd --query-masquerade  #检查是否允许伪装 IP

firewall-cmd --add-masquerade  #允许防火墙伪装 IP

firewall-cmd --remove-masquerade  #禁止防火墙伪装IP
```

### 添加转发规则
```
# 将80端口的流量转发至8080
firewall-cmd --add-forward-port=port=80:proto=tcp:toport=8080


# 将80端口的流量转发至192.168.0.1的8080端口
firewall-cmd --add-forward-port=port=80:proto=tcp:toaddr=192.168.0.1:toport=8080
```
修改后，输入以下命令重新载入防火墙
`firewall-cmd --reload`

**如果想要移除转发规则，将上述步骤中的** *add* 改为 *remove* 即可

### 查看相关信息
```
# 查看开放的端口
firewall-cmd --list-ports

# 查看开放的服务
firewall-cmd --list-services

# 查看防火墙规则
firewall-cmd --list-all
```
![image.png](https://img.hacpai.com/file/2019/09/image-5bdb6a34.png)



###  修改配置文件
如果配置完以上规则后仍不生效，检查防火墙是否开启 80 端口，如果80端口已经开启了，仍旧无法转发，可能由于内核参数文件 `sysctl.conf` 未配置 **ip转发功能**，具体配置如下：
`vim /etc/sysctl.conf`

在文本内容中添加

`net.ipv4.ip_forward = 1`

保存文件后，输入命令
`sysctl -p` 使其生效
