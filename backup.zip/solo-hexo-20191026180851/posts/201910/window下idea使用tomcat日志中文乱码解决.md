title: window下idea使用tomcat日志中文乱码解决
date: '2019-10-14 14:40:28'
updated: '2019-10-14 14:40:28'
tags: [Tomcat, 中文乱码]
permalink: /articles/2019/10/14/1571035227998.html
---
在网上找了无数的方法，对tomcat配置和idea一顿设置都不好用。都没有解决。后来在跟我同事老版本的tomcat对比一边后发现有一处可疑点。结果ok了。

当前**tomcat版本：8.5.39 (本人的 9.0版本)**

解决办法：

打开**conf**下`logging.properties`文件

将带有utf-8的编码配置项注释掉，完美解决。
```
1catalina.org.apache.juli.AsyncFileHandler.encoding = UTF-8
 
 
2localhost.org.apache.juli.AsyncFileHandler.encoding = UTF-8
 
 
3manager.org.apache.juli.AsyncFileHandler.encoding = UTF-8
 
 
4host-manager.org.apache.juli.AsyncFileHandler.encoding = UTF-8
 
 
java.util.logging.ConsoleHandler.encoding = UTF-8
 ```

其中**java.util.logging.ConsoleHandler.encoding = UTF-8**这一行是最关键的，只注释这一行也是可以的，上面那几行习惯性注释掉，不知道哪里用的。
————————————————
版权声明：本文为CSDN博主「grootblockchain」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/CaptainJava/article/details/89874318
