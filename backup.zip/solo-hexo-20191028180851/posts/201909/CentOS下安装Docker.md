title: CentOS下安装Docker
date: '2019-09-23 10:36:58'
updated: '2019-10-24 19:44:51'
tags: [Docker, Linux, CentOS]
permalink: /articles/2019/09/23/1569206218337.html
---
之前安装的Docker 版本低于1.9，所以无法使用docker network命令来创建网络，需卸载重新安装最新版本的docker,其中docker-ce是Docker社区版本,目前最新的是18.03.1-ce。yum安装采用的是阿里云镜像加速。

##  yum卸载、安装
卸载老版本的 docker 及其相关依赖

```
yum remove docker docker-common container-selinux docker-selinux docker-engine
```

#### 安装 yum-utils，它提供了 yum-config-manager，可用来管理yum源

```
yum install -y yum-utils
```

#### 添加yum源

```
yum-config-manager --add-repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

#### 更新yum索引

```
yum makecache fast
```

#### 安装 docker-ce

```
yum install -y docker-ce
```

#### 启动 docker

```
systemctl start docker
```
#### 设置开机启动docker

```
systemctl enable docker
```

#### 验证是否安装成功

```
docker info
```

#### 安装指定版本的Docker-ce

```
yum list docker-ce --showduplicates|sort -r  
yum install 18.03.1.ce -y
```

## 镜像加速
您可以通过修改 **daemon配置文件/etc/docker/daemon.json**来使用加速器

```
mkdir -p /etc/docker
tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://80ks6yul.mirror.aliyuncs.com"]
}
EOF
systemctl daemon-reload
systemctl restart docker
```



## 卸载
```
yum remove docker-ce  
rm -rf /var/lib/docker
```
