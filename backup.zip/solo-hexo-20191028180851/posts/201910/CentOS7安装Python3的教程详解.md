title: CentOS7安装Python3的教程详解
date: '2019-10-23 18:17:22'
updated: '2019-10-23 18:17:22'
tags: [Python, CentOS]
permalink: /articles/2019/10/23/1571825841966.html
---
首先执行


```
yum -y groupinstall` `'Development tools'


yum -y install  openssl-devel  bzip2-devel expat-devel gdbm-devel readline-devel sqlite-devel

// Python3.7以上需要装libfii-devel

yum  install  libffi-devel -y
```


### 安装各种依赖包

其次要获取Python3源文件，在[https://www.python.org/downloads/release/python-373/](https://www.python.org/downloads/release/python-373/)下的Files中获取最新的Python包(Gzipped source tarball)

本次要获取的地址是[https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz](https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz) 进入Linux，Root用户默认在/Root/目录下

### **1.获取python3包**

wget [https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz](https://www.python.org/ftp/python/3.7.3/Python-3.7.3.tgz)

### **2.解压Python3包**

```
tar -xvf Python-3.7.3.tgz
```

### 3.创建Python3文件夹
（这个用来存放Python编译后的程序，我的理解是Python3下载的是源代码，需要通过编译->安装。在编译前，可以通过./configure设置安装目录）

```
mkdir /usr/local/python3
```

### 4.配置安装目录
进入 第2步 解压后的文件夹(与下载的Python-3.7.3同目录,我的是/Root/下)，并配置安装目录

```
cd Python-3.7.3/

./configure --prefix=/usr/local/python3
```

### 5.源码编译

```
make
```

### 6.源码安装

```
make install
```

### 7.创建软连接

```
ln -s /usr/local/python3/bin/python3 /usr/bin/python3

ln -s /usr/local/python3/bin/pip3 /usr/bin/pip3
```

### 8.测试  

python3和pip3就装好了
