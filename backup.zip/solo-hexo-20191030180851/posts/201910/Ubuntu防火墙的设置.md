title: Ubuntu防火墙的设置
date: '2019-10-09 09:40:09'
updated: '2019-10-09 09:40:09'
tags: [Ubuntu, Linux, ufw, 端口]
permalink: /articles/2019/10/09/1570585209302.html
---
**1.防火墙的打开**

**sudo ufw enable**

**2.防火墙的重启**

**sudo ufw reload**

**3.打开想要的端口（以5432为例）**

**ufw allow 5432**

![TIM截图20191009093731.png](https://img.hacpai.com/file/2019/10/TIM截图20191009093731-f7fc47ea.png)

**4.查看本机端口使用情况**
![TIM截图20191009093731.png](https://img.hacpai.com/file/2019/10/TIM截图20191009093731-6d2ad253.png)

