title: VSCode自定义插件安装位置
date: '2019-11-16 15:09:53'
updated: '2019-11-16 15:09:53'
tags: [VSCode]
permalink: /articles/2019/11/16/1573888193179.html
---
vscode插件默认的安装位置是 

```
C:\Users\用户名\.vscode\extensions
```

如果不想把插件安装在 C 盘的话，自己新建一个文件来存储插件，然后在**快捷方式** 中修改启动路径

新的插件目录：

```
D:\Code\VSCode\extensions
```

对于 VSCode 的快捷方式，右键属性

![QQ截图20191116150616.png](https://img.hacpai.com/file/2019/11/QQ截图20191116150616-2b1164f6.png)

红框框住的地方原来是：

```
D:\Code\VSCode\Code.exe
// VSCode.exe的路径
```

改为：

```
D:\Code\VSCode\Code.exe --extensions-dir "D:\Code\VSCode\extensions"
```
