title: CentOS下安装JAVA环境
date: '2019-11-03 23:26:08'
updated: '2019-11-03 23:26:08'
tags: [CentOS, Java]
permalink: /articles/2019/11/03/1572794768315.html
---
### 下载 JDK 1.8的压缩包
**通过 XFTP 上传到服务器，然后在** `/usr/local`下新建一个目录

```
mkdir /usr/local/java
```
把压缩包放在该目录，并进入进行解压

```
tar zxvf 压缩包名称
```

![解压JDK18.png](https://img.hacpai.com/file/2019/11/解压JDK18-2d88c387.png)

删除压缩包
```
rm -f 压缩包
```

### 环境配置

```
vim /etc/profile
```

在途中此处，添加如下代码
![环境变量.png](https://img.hacpai.com/file/2019/11/环境变量-2112193c.png)

```
export JAVA_HOME=/usr/local/java/jdk1.8.0_11

export CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar

export PATH=$PATH:$JAVA_HOME/bin

```

**注意，其中的 `JAVA_HOME` 后跟随的路径是刚刚解压完毕的文件夹的名称**

保存退出之后，需要输入命令让刚刚的修改生效

```
source /etc/profile
```

随后输入

```
java -version
```
查看是否成功

![成功.png](https://img.hacpai.com/file/2019/11/成功-0b67938b.png)


