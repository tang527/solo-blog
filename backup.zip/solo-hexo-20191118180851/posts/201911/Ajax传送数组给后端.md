title: Ajax传送数组给后端
date: '2019-11-18 10:05:05'
updated: '2019-11-18 10:05:05'
tags: [Java, Ajax]
permalink: /articles/2019/11/18/1574042705187.html
---
目前暂时只更新 Java Servlet

### 前端

目前有一个形如 ```snoList = [2,3,4]```的数组类型，目前要送给后端

**ajax**代码如下

```
$.ajax({
	url: "/user/delete",
	type: "POST",
	dataType: "json",
	traditional: true,
	data: {
		snoList: snoList
	},
	success(){}
});
```

### 后台

**Java Servlet** 代码如下

``` java
@WebServlet("/user/delete")
public class DeleteUserServlet extends HttpServlet {

    private UserDao userDao;
    private PrintWriter out;

    @Override
    public void init() throws ServletException {
        userDao = new UserDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        out = response.getWriter();
        Gson gson = new Gson();

        String[] snoList = request.getParameterValues("snoList");
        for(String sno:snoList) {
            System.out.println(sno);
        }
    }
```

> 注意：使用方法
```
String arr[] = request.getParameterValues("arr");
// 如果ajax请求没有加 traditional :true
// 则应该在获取数组时在参数名后边加上[]
String arr[] = request.getParameterValues("arr[]");
```
