title: Windows10下win+R 下一些常用的 程序
date: '2019-09-25 17:15:30'
updated: '2019-09-25 17:15:30'
tags: [Windows10]
permalink: /articles/2019/09/25/1569402930596.html
---
### 计算机管理
`compmgmt.msc`

---
![TIM截图20190925171259.png](https://img.hacpai.com/file/2019/09/TIM截图20190925171259-92eca251.png)

### 服务管理

---
`services.msc`
![TIM截图20190925171450.png](https://img.hacpai.com/file/2019/09/TIM截图20190925171450-6b810363.png)

